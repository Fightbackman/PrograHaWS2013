import java.util.*;

public class PersonAdministration {
    private Collection<Person> persons;
    public PersonAdministration(Collection<Person> ps) {
        this.persons = ps;
    }
    public boolean contains(Person p) {
        return this.persons.contains(p);
    }
    public int size() {
        return this.persons.size();
    }
    public static void main(String[] args) {
        Person adam = new Person("Adam", "Schmidt", 12, 8, 1976, 1);
        Person berta = new Person("Berta", "Schneider", 12, 8, 1976, 2);
        Collection<Person> persons = new TreeSet<Person>();
        persons.add(adam);
        persons.add(berta);
        PersonAdministration admin = new PersonAdministration(persons);
        if (admin.size() < 2) System.out.println("Who is missing?");
        persons = new HashSet<Person>();
        persons.add(adam);
        persons.add(berta);
        admin = new PersonAdministration(persons);
        adam.marry(berta);
        if (!admin.contains(adam)) System.out.println("Where is Adam?");
    }
}