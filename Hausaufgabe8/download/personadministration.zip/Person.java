public class Person implements Comparable<Person> {
    private int dayOfBirth;
    private int monthOfBirth;
    private int yearOfBirth;
    private String firstName; // must not be null
    private String lastName;  // must not be null
    private int identityNumber;
    public Person(String first, String last, int day, int month, int year, int idNum) {
        this.dayOfBirth = day;
        this.monthOfBirth = month;
        this.yearOfBirth = year;
        this.firstName = first;
        this.lastName = last;
        this.identityNumber = idNum;
    }
    public String getFirstName() {
        return this.firstName;
    }
    public String getLastName() {
        return this.lastName;
    }
    public int getIdentityNumber() {
        return this.identityNumber;
    }
    public void marry(Person that) {
        this.lastName = that.lastName;
    }
    public int compareTo(Person that) {
        int res = this.yearOfBirth - that.yearOfBirth;
        if (res != 0) return res;
        res = this.monthOfBirth - that.monthOfBirth;
        if (res != 0) return res;
        return this.dayOfBirth - that.dayOfBirth;
    }
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + dayOfBirth;
        result = prime * result + firstName.hashCode();
        result = prime * result + identityNumber;
        result = prime * result + lastName.hashCode();
        result = prime * result + monthOfBirth;
        return prime * result + yearOfBirth;
    }
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Person other = (Person) obj;
        if (dayOfBirth != other.dayOfBirth) return false;
        if (!firstName.equals(other.firstName)) return false;
        if (identityNumber != other.identityNumber) return false;
        if (!lastName.equals(other.lastName)) return false;
        if (monthOfBirth != other.monthOfBirth) return false;
        if (yearOfBirth != other.yearOfBirth) return false;
        return true;
    }
}